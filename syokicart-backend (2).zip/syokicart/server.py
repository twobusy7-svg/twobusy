"""SyokiCart backend: FastAPI + SQLite. Payment collection is intentionally not implemented
(orders stay payment_status="pending").

Run:  uvicorn server:app --host 0.0.0.0 --port 8000
Env:  SYOKI_DB          sqlite path (default ./syokicart.db)
      SYOKI_DEV_OTP     "1" (default) = fixed code 123456 and the code is returned in the API
                        response; "0" = random codes, sent by SMS (Africa's Talking) or logged
      AT_USERNAME, AT_API_KEY, AT_SENDER   Africa's Talking credentials (optional, used when DEV_OTP=0)
      SYOKI_ADMIN_PHONES    comma list of phones that are admins (default 0700000000)
      SYOKI_VENDOR_SEED     "0711000001:naivas" style comma list (default that one)
"""
import hashlib, json, os, re, secrets, sqlite3, time, urllib.parse, urllib.request
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Optional

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse

BASE = Path(__file__).parent
DB_PATH = os.environ.get("SYOKI_DB", str(BASE / "syokicart.db"))
DEV_OTP = os.environ.get("SYOKI_DEV_OTP", "1") != "0"
OTP_TTL = 5 * 60
TOKEN_TTL = 30 * 24 * 3600
CAT = json.load(open(BASE / "catalog.json", encoding="utf-8"))
SLOTS = CAT["slots"]

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(phone TEXT PRIMARY KEY, name TEXT, role TEXT NOT NULL DEFAULT 'customer', vendor_id INTEGER);
CREATE TABLE IF NOT EXISTS tokens(hash TEXT PRIMARY KEY, phone TEXT NOT NULL, expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS otps(phone TEXT PRIMARY KEY, code_hash TEXT NOT NULL, expires INTEGER NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, sent_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS vendors(id INTEGER PRIMARY KEY, slug TEXT UNIQUE, name TEXT, delivery_type TEXT, age_restricted INTEGER, is_service INTEGER, ho INTEGER, hc INTEGER);
CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT, vendor_id INTEGER NOT NULL, name TEXT NOT NULL, unit TEXT NOT NULL, price INTEGER NOT NULL, available INTEGER NOT NULL DEFAULT 1, seed INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY AUTOINCREMENT, cust TEXT NOT NULL, ref TEXT, estate TEXT, det TEXT, cphone TEXT, slot TEXT, status TEXT, sub INTEGER, fee INTEGER, total INTEGER, rider_name TEXT, rider_phone TEXT, created INTEGER, UNIQUE(cust, ref));
CREATE TABLE IF NOT EXISTS fulfillments(id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL, vendor_id INTEGER NOT NULL, dt TEXT, status TEXT, sub INTEGER, fee INTEGER DEFAULT 0, updated INTEGER);
CREATE TABLE IF NOT EXISTS items(id INTEGER PRIMARY KEY AUTOINCREMENT, fulfillment_id INTEGER NOT NULL, product_id INTEGER, name TEXT, unit TEXT, unit_price INTEGER, qty INTEGER);
CREATE INDEX IF NOT EXISTS ix_o_cust ON orders(cust);
CREATE INDEX IF NOT EXISTS ix_f_order ON fulfillments(order_id);
CREATE INDEX IF NOT EXISTS ix_f_vendor ON fulfillments(vendor_id);
"""


def db():
    c = sqlite3.connect(DB_PATH, timeout=15, isolation_level=None)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA foreign_keys=ON")
    return c


def init():
    c = db()
    c.executescript(SCHEMA)
    for v in CAT["vendors"]:
        c.execute("INSERT OR IGNORE INTO vendors VALUES(?,?,?,?,?,?,?,?)",
                  (v["id"], v["slug"], v["name"], v["delivery_type"], int(v["age_restricted"]), int(v["is_service"]), v["ho"], v["hc"]))
        for p in v["products"]:
            c.execute("INSERT OR IGNORE INTO products(id,vendor_id,name,unit,price,available,seed) VALUES(?,?,?,?,?,?,1)",
                      (p["id"], v["id"], p["name"], p["unit"], p["price"], int(p["available"])))
    slug = {r["slug"]: r["id"] for r in c.execute("SELECT id,slug FROM vendors")}
    for ph in filter(None, os.environ.get("SYOKI_ADMIN_PHONES", "0700000000").split(",")):
        c.execute("INSERT INTO users(phone,role) VALUES(?, 'admin') ON CONFLICT(phone) DO NOTHING", (norm(ph.strip()) or ph.strip(),))
    for pair in filter(None, os.environ.get("SYOKI_VENDOR_SEED", "0711000001:naivas").split(",")):
        ph, s = pair.split(":")
        if s in slug:
            c.execute("INSERT INTO users(phone,role,vendor_id) VALUES(?, 'vendor', ?) ON CONFLICT(phone) DO NOTHING", (ph, slug[s]))
    c.close()


# ---------- helpers ----------
class ApiError(Exception):
    def __init__(self, code, message, status=400):
        self.code, self.message, self.status = code, message, status


def norm(p) -> Optional[str]:
    p = re.sub(r"[\s\-()]", "", str(p or ""))
    m = re.match(r"^\+?254([17]\d{8})$", p)
    if m:
        return "0" + m.group(1)
    return p if re.match(r"^0[17]\d{8}$", p) else None


def intl(p):
    return "+254" + p[1:]


def sha(s):
    return hashlib.sha256(s.encode()).hexdigest()


def open_now(v) -> bool:
    ho, hc = v["ho"], v["hc"]
    if ho == 0 and hc == 24:
        return True
    h = (datetime.now(timezone.utc) + timedelta(hours=3)).hour
    return ho <= h < hc if ho < hc else (h >= ho or h < hc)


def user_view(u):
    return {"id": u["phone"], "phone": intl(u["phone"]), "name": u["name"], "role": u["role"], "vendor_id": u["vendor_id"]}


def get_user(c, phone):
    u = c.execute("SELECT * FROM users WHERE phone=?", (phone,)).fetchone()
    if u:
        return u
    c.execute("INSERT OR IGNORE INTO users(phone) VALUES(?)", (phone,))
    return c.execute("SELECT * FROM users WHERE phone=?", (phone,)).fetchone()


def auth(c, request: Request):
    h = request.headers.get("authorization", "")
    if not h.lower().startswith("bearer "):
        raise ApiError("unauthorized", "Log in first.", 401)
    r = c.execute("SELECT phone FROM tokens WHERE hash=? AND expires>?", (sha(h[7:].strip()), int(time.time()))).fetchone()
    if not r:
        raise ApiError("unauthorized", "Your session expired. Log in again.", 401)
    return get_user(c, r["phone"])


def need_role(u, *roles):
    if u["role"] not in roles:
        raise ApiError("forbidden", "You cannot do that with this account.", 403)


async def body(request: Request) -> dict:
    try:
        b = await request.json()
    except Exception:
        return {}
    return b if isinstance(b, dict) else {}


def isint(n, mx):
    return isinstance(n, int) and not isinstance(n, bool) and 1 <= n <= mx


FEE_RIDER_FIRST, FEE_RIDER_EXTRA, FEE_LORRY = 100, 50, 1500


def refresh(c, oid):
    """Recompute fees, totals and the derived order status from the fulfillments."""
    fs = c.execute("SELECT * FROM fulfillments WHERE order_id=? ORDER BY vendor_id", (oid,)).fetchall()
    live = [f for f in fs if f["status"] not in ("rejected", "cancelled")]
    riders, sub, fee = 0, 0, 0
    c.execute("UPDATE fulfillments SET fee=0 WHERE order_id=?", (oid,))
    for f in live:
        if f["dt"] == "rider":
            riders += 1
            x = FEE_RIDER_FIRST if riders == 1 else FEE_RIDER_EXTRA
        else:
            x = FEE_LORRY if f["dt"] == "lorry" else 0
        c.execute("UPDATE fulfillments SET fee=? WHERE id=?", (x, f["id"]))
        sub += f["sub"]
        fee += x
    st = {f["status"] for f in live}
    if not live:
        status = "cancelled"
    elif st == {"delivered"}:
        status = "delivered"
    elif st & {"out_for_delivery", "delivered"}:
        status = "on_the_way"
    elif st & {"accepted", "ready"}:
        status = "confirmed"
    else:
        status = "placed"
    c.execute("UPDATE orders SET sub=?,fee=?,total=?,status=? WHERE id=?", (sub, fee, sub + fee, status, oid))


def order_view(c, o):
    fs = c.execute("SELECT f.*, v.name vname, v.age_restricted FROM fulfillments f JOIN vendors v ON v.id=f.vendor_id WHERE order_id=? ORDER BY f.id", (o["id"],)).fetchall()
    out = []
    for f in fs:
        its = c.execute("SELECT name,unit,unit_price,qty FROM items WHERE fulfillment_id=? ORDER BY id", (f["id"],)).fetchall()
        out.append({"id": f["id"], "vendor": f["vname"], "delivery_type": f["dt"], "status": f["status"], "subtotal": f["sub"],
                    "delivery_fee": f["fee"], "requires_id_check": bool(f["age_restricted"]), "items": [dict(i) for i in its]})
    return {"id": o["id"], "status": o["status"], "subtotal": o["sub"], "delivery_fee": o["fee"], "total": o["total"],
            "payment_status": "pending", "estate": o["estate"], "address_details": o["det"], "contact_phone": o["cphone"],
            "slot": o["slot"], "notes": None,
            "created_at": datetime.fromtimestamp(o["created"], timezone.utc).isoformat().replace("+00:00", "Z"),
            "rider": {"name": o["rider_name"], "phone": o["rider_phone"]} if o["rider_name"] else None, "fulfillments": out}


# ---------- OTP ----------
def send_sms(phone, text):
    u, k = os.environ.get("AT_USERNAME"), os.environ.get("AT_API_KEY")
    if not (u and k):
        print(f"[sms:console] to {intl(phone)}: {text}", flush=True)
        return
    data = urllib.parse.urlencode({"username": u, "to": intl(phone), "message": text, **({"from": os.environ["AT_SENDER"]} if os.environ.get("AT_SENDER") else {})}).encode()
    host = "api.sandbox.africastalking.com" if u == "sandbox" else "api.africastalking.com"
    req = urllib.request.Request(f"https://{host}/version1/messaging", data=data, headers={"apiKey": k, "Accept": "application/json"})
    try:
        urllib.request.urlopen(req, timeout=10).read()
    except Exception as e:
        print("[sms] failed:", e, flush=True)
        raise ApiError("sms_failed", "Could not send the code. Try again shortly.", 502)


# ---------- app ----------
app = FastAPI(title="SyokiCart API")
app.add_middleware(CORSMiddleware, allow_origins=os.environ.get("SYOKI_CORS", "*").split(","), allow_methods=["*"], allow_headers=["*"])
init()


@app.exception_handler(ApiError)
async def api_err(_, e: ApiError):
    return JSONResponse({"error": {"code": e.code, "message": e.message}}, status_code=e.status)


@app.exception_handler(Exception)
async def any_err(_, e: Exception):
    print("ERROR", repr(e), flush=True)
    return JSONResponse({"error": {"code": "server_error", "message": "Something went wrong."}}, status_code=500)


@app.get("/healthz")
def healthz():
    return {"ok": True}


@app.get("/api/catalog")
def catalog():
    c = db()
    vs = []
    for v in CAT["vendors"]:
        row = c.execute("SELECT * FROM vendors WHERE id=?", (v["id"],)).fetchone()
        ps = c.execute("SELECT id,vendor_id,name,unit,price,available FROM products WHERE vendor_id=? ORDER BY id", (v["id"],)).fetchall()
        # static fields (img, eta, hours...) come from the seed file; dynamic ones from the DB
        nv = {**v, "products": []}
        seed = {p["id"]: p for p in v["products"]}
        for p in ps:
            d = {**seed.get(p["id"], {}), **dict(p)}
            d["available"] = bool(p["available"])
            nv["products"].append(d)
        nv["open_now"] = open_now(row)
        vs.append(nv)
    c.close()
    return {"categories": CAT["categories"], "slots": SLOTS, "vendors": vs}


@app.post("/api/auth/request-otp")
async def request_otp(request: Request):
    b = await body(request)
    p = norm(b.get("phone"))
    if not p:
        raise ApiError("invalid_phone", "Enter a valid Kenyan number like 0712345678.")
    c = db()
    old = c.execute("SELECT sent_at FROM otps WHERE phone=?", (p,)).fetchone()
    if old and time.time() - old["sent_at"] < 30 and not DEV_OTP:
        raise ApiError("too_soon", "Wait 30 seconds before asking for another code.", 429)
    code = "123456" if DEV_OTP else f"{secrets.randbelow(10**6):06d}"
    now = int(time.time())
    c.execute("INSERT OR REPLACE INTO otps VALUES(?,?,?,0,?)", (p, sha(p + code), now + OTP_TTL, now))
    c.close()
    if not DEV_OTP:
        send_sms(p, f"Your SyokiCart code is {code}. It expires in 5 minutes.")
    r = {"sent": True, "expires_in_minutes": OTP_TTL // 60}
    if DEV_OTP:
        r["dev_otp"] = code
    return r


@app.post("/api/auth/verify")
async def verify(request: Request):
    b = await body(request)
    p = norm(b.get("phone"))
    c = db()
    row = c.execute("SELECT * FROM otps WHERE phone=?", (p,)).fetchone() if p else None
    if not row or row["expires"] < time.time():
        raise ApiError("otp_wrong", "Code expired or not requested. Ask for a new one.", 401)
    if row["attempts"] >= 5:
        raise ApiError("otp_locked", "Too many wrong tries. Ask for a new code.", 429)
    if not secrets.compare_digest(row["code_hash"], sha(p + str(b.get("otp", "")))):
        c.execute("UPDATE otps SET attempts=attempts+1 WHERE phone=?", (p,))
        raise ApiError("otp_wrong", "Wrong code. Check it and try again.", 401)
    c.execute("DELETE FROM otps WHERE phone=?", (p,))
    u = get_user(c, p)
    if b.get("name") and not u["name"]:
        c.execute("UPDATE users SET name=? WHERE phone=?", (str(b["name"]).strip()[:60], p))
        u = get_user(c, p)
    tok = secrets.token_urlsafe(32)
    c.execute("INSERT INTO tokens VALUES(?,?,?)", (sha(tok), p, int(time.time()) + TOKEN_TTL))
    c.execute("DELETE FROM tokens WHERE expires<?", (int(time.time()),))
    r = {"token": tok, "user": user_view(u)}
    c.close()
    return r


@app.get("/api/me")
def me(request: Request):
    c = db()
    u = auth(c, request)
    c.close()
    return user_view(u)


# ----- customer orders -----
@app.get("/api/orders/version")
def orders_version(request: Request):
    c = db()
    u = auth(c, request)
    rows = c.execute("SELECT o.id, GROUP_CONCAT(f.status) s FROM orders o JOIN fulfillments f ON f.order_id=o.id WHERE o.cust=? GROUP BY o.id ORDER BY o.id DESC", (u["phone"],)).fetchall()
    c.close()
    return {"v": json.dumps([[r["id"], r["s"]] for r in rows], separators=(",", ":"))}


@app.get("/api/orders")
def list_orders(request: Request):
    c = db()
    u = auth(c, request)
    os_ = c.execute("SELECT * FROM orders WHERE cust=? ORDER BY id DESC LIMIT 100", (u["phone"],)).fetchall()
    r = {"orders": [order_view(c, o) for o in os_]}
    c.close()
    return r


@app.get("/api/orders/{oid}")
def get_order(oid: int, request: Request):
    c = db()
    u = auth(c, request)
    o = c.execute("SELECT * FROM orders WHERE id=? AND cust=?", (oid, u["phone"])).fetchone()
    if not o:
        raise ApiError("not_found", "Order not found.", 404)
    r = order_view(c, o)
    c.close()
    return r


@app.post("/api/orders/{oid}/cancel")
def cancel_order(oid: int, request: Request):
    c = db()
    u = auth(c, request)
    c.execute("BEGIN IMMEDIATE")
    o = c.execute("SELECT * FROM orders WHERE id=? AND cust=?", (oid, u["phone"])).fetchone()
    if not o:
        c.execute("ROLLBACK")
        raise ApiError("not_found", "Order not found.", 404)
    if c.execute("SELECT 1 FROM fulfillments WHERE order_id=? AND status NOT IN ('placed','cancelled')", (oid,)).fetchone():
        c.execute("ROLLBACK")
        raise ApiError("too_late", "A shop has already accepted this order. Contact support to cancel.", 409)
    c.execute("UPDATE fulfillments SET status='cancelled', updated=? WHERE order_id=?", (int(time.time()), oid))
    refresh(c, oid)
    c.execute("COMMIT")
    r = order_view(c, c.execute("SELECT * FROM orders WHERE id=?", (oid,)).fetchone())
    c.close()
    return r


@app.post("/api/orders")
async def create_order(request: Request):
    b = await body(request)
    c = db()
    u = auth(c, request)
    ref = str(b["client_ref"])[:64] if b.get("client_ref") else None
    if ref:
        ex = c.execute("SELECT * FROM orders WHERE cust=? AND ref=?", (u["phone"], ref)).fetchone()
        if ex:
            return order_view(c, ex)
    items = b.get("items")
    if not isinstance(items, list) or not 1 <= len(items) <= 50:
        raise ApiError("invalid_items", "Add between 1 and 50 items to your order.")
    q: dict[int, int] = {}
    for it in items:
        if not isinstance(it, dict) or not isinstance(it.get("product_id"), int) or not isint(it.get("qty"), 999):
            raise ApiError("invalid_items", "Quantity must be between 1 and 999.")
        q[it["product_id"]] = q.get(it["product_id"], 0) + it["qty"]
    if any(n > 999 for n in q.values()):
        raise ApiError("invalid_items", "Quantity must be between 1 and 999.")
    est = str(b.get("estate") or "").strip()
    if len(est) < 2:
        raise ApiError("invalid_address", "Add your estate so the rider can find you.")
    by: dict[int, list] = {}
    vend: dict[int, Any] = {}
    for pid in q:
        p = c.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()
        if not p:
            raise ApiError("unknown_product", "One of the items no longer exists.", 404)
        v = vend.get(p["vendor_id"]) or c.execute("SELECT * FROM vendors WHERE id=?", (p["vendor_id"],)).fetchone()
        vend[v["id"]] = v
        if not p["available"]:
            raise ApiError("unavailable", p["name"] + " is not available right now.", 409)
        if not open_now(v):
            raise ApiError("vendor_closed", v["name"] + " is closed right now.", 409)
        by.setdefault(v["id"], []).append(p)
    vs = sorted(by)
    if any(vend[i]["age_restricted"] for i in vs) and b.get("age_confirmed") is not True:
        raise ApiError("age_confirmation_required", "Confirm you are 18 or older to order liquor.")
    svc = any(vend[i]["is_service"] for i in vs)
    if svc and b.get("slot") not in SLOTS:
        raise ApiError("slot_required", "Choose a pickup or visit time.")
    cp = norm(b.get("contact_phone"))
    now = int(time.time())
    c.execute("BEGIN IMMEDIATE")
    try:
        cur = c.execute("INSERT INTO orders(cust,ref,estate,det,cphone,slot,status,sub,fee,total,created) VALUES(?,?,?,?,?,?, 'placed',0,0,0,?)",
                        (u["phone"], ref, est, str(b.get("address_details") or "")[:200], intl(cp or u["phone"]), b["slot"] if svc else None, now))
        oid = cur.lastrowid
        for vid in vs:
            its = [(p, q[p["id"]]) for p in by[vid]]
            sub = sum(p["price"] * n for p, n in its)
            fc = c.execute("INSERT INTO fulfillments(order_id,vendor_id,dt,status,sub,updated) VALUES(?,?,?, 'placed',?,?)", (oid, vid, vend[vid]["delivery_type"], sub, now))
            for p, n in its:
                c.execute("INSERT INTO items(fulfillment_id,product_id,name,unit,unit_price,qty) VALUES(?,?,?,?,?,?)", (fc.lastrowid, p["id"], p["name"], p["unit"], p["price"], n))
        refresh(c, oid)
        c.execute("COMMIT")
    except sqlite3.IntegrityError:  # duplicate client_ref race
        c.execute("ROLLBACK")
        ex = c.execute("SELECT * FROM orders WHERE cust=? AND ref=?", (u["phone"], ref)).fetchone()
        return order_view(c, ex)
    except Exception:
        c.execute("ROLLBACK")
        raise
    r = order_view(c, c.execute("SELECT * FROM orders WHERE id=?", (oid,)).fetchone())
    c.close()
    return JSONResponse(r, status_code=201)


# ----- admin -----
@app.post("/api/admin/users/role")
async def set_role(request: Request):
    b = await body(request)
    c = db()
    u = auth(c, request)
    need_role(u, "admin")
    p = norm(b.get("phone"))
    role = b.get("role")
    if not p or role not in ("customer", "rider", "vendor", "admin"):
        raise ApiError("invalid_request", "Send a valid phone and a role.")
    vid = None
    if role == "vendor":
        v = c.execute("SELECT id FROM vendors WHERE slug=?", (b.get("vendor_slug"),)).fetchone()
        if not v:
            raise ApiError("invalid_vendor", "Send a valid vendor_slug for vendor accounts.")
        vid = v["id"]
    get_user(c, p)
    c.execute("UPDATE users SET role=?, vendor_id=? WHERE phone=?", (role, vid, p))
    r = user_view(get_user(c, p))
    c.close()
    return r


# ----- vendor -----
VS = {"placed": ["accepted", "rejected"], "accepted": ["ready"]}
VD = {"accepted": ["out_for_delivery"], "ready": ["out_for_delivery"], "out_for_delivery": ["delivered"]}


def vendor_rows(c, u):
    return c.execute("SELECT f.*, o.estate, o.det, o.cphone, o.slot FROM fulfillments f JOIN orders o ON o.id=f.order_id WHERE f.vendor_id=? ORDER BY f.id DESC LIMIT 200", (u["vendor_id"],)).fetchall()


@app.get("/api/vendor/orders/version")
def vendor_version(request: Request):
    c = db()
    u = auth(c, request)
    need_role(u, "vendor")
    r = {"v": json.dumps([r["status"] for r in vendor_rows(c, u)], separators=(",", ":"))}
    c.close()
    return r


@app.get("/api/vendor/orders")
def vendor_orders(request: Request):
    c = db()
    u = auth(c, request)
    need_role(u, "vendor")
    out = []
    for f in vendor_rows(c, u):
        its = c.execute("SELECT name,unit,unit_price,qty FROM items WHERE fulfillment_id=? ORDER BY id", (f["id"],)).fetchall()
        r = {"fulfillment_id": f["id"], "order_id": f["order_id"], "status": f["status"], "delivery_type": f["dt"], "subtotal": f["sub"],
             "estate": f["estate"], "slot": f["slot"], "notes": None, "items": [dict(i) for i in its]}
        if f["dt"] != "rider":  # rider-delivered orders keep the customer's address private from the shop
            r["address_details"], r["customer_phone"] = f["det"], f["cphone"]
        out.append(r)
    c.close()
    return {"orders": out}


@app.post("/api/vendor/orders/{fid}/status")
async def vendor_status(fid: int, request: Request):
    b = await body(request)
    c = db()
    u = auth(c, request)
    need_role(u, "vendor")
    c.execute("BEGIN IMMEDIATE")
    f = c.execute("SELECT * FROM fulfillments WHERE id=? AND vendor_id=?", (fid, u["vendor_id"])).fetchone()
    if not f:
        c.execute("ROLLBACK")
        raise ApiError("not_found", "Order not found.", 404)
    ok = VS.get(f["status"], []) + (VD.get(f["status"], []) if f["dt"] != "rider" else [])
    if b.get("status") not in ok:
        c.execute("ROLLBACK")
        raise ApiError("invalid_transition", f"Cannot move an order from {f['status']} to {b.get('status')}.", 409)
    c.execute("UPDATE fulfillments SET status=?, updated=? WHERE id=?", (b["status"], int(time.time()), fid))
    refresh(c, f["order_id"])
    c.execute("COMMIT")
    c.close()
    return {"fulfillment_id": fid, "status": b["status"]}


@app.post("/api/vendor/products")
async def add_product(request: Request):
    b = await body(request)
    c = db()
    u = auth(c, request)
    need_role(u, "vendor")
    name, unit = str(b.get("name") or "").strip()[:120], str(b.get("unit") or "").strip()[:30]
    if len(name) < 2 or not unit:
        raise ApiError("invalid_product", "Give the product a name and a unit.")
    if not isint(b.get("price"), 10_000_000):
        raise ApiError("invalid_price", "Price must be a whole number of shillings.")
    cur = c.execute("INSERT INTO products(vendor_id,name,unit,price,available) VALUES(?,?,?,?,1)", (u["vendor_id"], name, unit, b["price"]))
    c.close()
    return JSONResponse({"id": cur.lastrowid, "vendor_id": u["vendor_id"], "name": name, "unit": unit, "price": b["price"], "available": True}, status_code=201)


@app.post("/api/vendor/products/{pid}")
@app.put("/api/vendor/products/{pid}")
@app.patch("/api/vendor/products/{pid}")
async def edit_product(pid: int, request: Request):
    b = await body(request)
    c = db()
    u = auth(c, request)
    need_role(u, "vendor")
    p = c.execute("SELECT * FROM products WHERE id=? AND vendor_id=?", (pid, u["vendor_id"])).fetchone()
    if not p:
        raise ApiError("not_found", "Product not found.", 404)
    if not isint(b.get("price"), 10_000_000):
        raise ApiError("invalid_price", "Price must be a whole number of shillings.")
    av = b.get("available") is not False
    c.execute("UPDATE products SET price=?, available=? WHERE id=?", (b["price"], int(av), pid))
    c.close()
    seed = next((x for v in CAT["vendors"] for x in v["products"] if x["id"] == pid), {})
    return {**seed, "id": pid, "vendor_id": p["vendor_id"], "name": p["name"], "unit": p["unit"], "price": b["price"], "available": av}


# ----- rider (extra: lets rider-delivered fulfillments complete without the shop) -----
@app.get("/api/rider/jobs")
def rider_jobs(request: Request):
    c = db()
    u = auth(c, request)
    need_role(u, "rider", "admin")
    rows = c.execute("""SELECT f.id fid, f.order_id, f.status, v.name vendor, o.estate, o.det, o.cphone, o.rider_phone
                        FROM fulfillments f JOIN orders o ON o.id=f.order_id JOIN vendors v ON v.id=f.vendor_id
                        WHERE f.dt='rider' AND (f.status='ready' OR (f.status='out_for_delivery' AND o.rider_phone=?)) ORDER BY f.id""", (intl(u["phone"]),)).fetchall()
    c.close()
    return {"jobs": [{"fulfillment_id": r["fid"], "order_id": r["order_id"], "status": r["status"], "pickup": r["vendor"], "estate": r["estate"],
                      "address_details": r["det"], "customer_phone": r["cphone"]} for r in rows]}


@app.post("/api/rider/jobs/{fid}/status")
async def rider_status(fid: int, request: Request):
    b = await body(request)
    c = db()
    u = auth(c, request)
    need_role(u, "rider", "admin")
    c.execute("BEGIN IMMEDIATE")
    f = c.execute("SELECT f.*, o.rider_phone FROM fulfillments f JOIN orders o ON o.id=f.order_id WHERE f.id=? AND f.dt='rider'", (fid,)).fetchone()
    want = b.get("status")
    me_ph = intl(u["phone"])
    if not f:
        c.execute("ROLLBACK")
        raise ApiError("not_found", "Job not found.", 404)
    ok = (f["status"] == "ready" and want == "out_for_delivery" and (not f["rider_phone"] or f["rider_phone"] == me_ph)) or \
         (f["status"] == "out_for_delivery" and want == "delivered" and f["rider_phone"] == me_ph)
    if not ok:
        c.execute("ROLLBACK")
        raise ApiError("invalid_transition", f"Cannot move a job from {f['status']} to {want}.", 409)
    if want == "out_for_delivery" and not f["rider_phone"]:
        c.execute("UPDATE orders SET rider_name=?, rider_phone=? WHERE id=?", (u["name"] or "Rider", me_ph, f["order_id"]))
    c.execute("UPDATE fulfillments SET status=?, updated=? WHERE id=?", (want, int(time.time()), fid))
    refresh(c, f["order_id"])
    c.execute("COMMIT")
    c.close()
    return {"fulfillment_id": fid, "status": want}


@app.api_route("/api/{rest:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
def api_404(rest: str):
    raise ApiError("not_found", "Not found", 404)


@app.get("/")
def index():
    return FileResponse(BASE / "index.html", headers={"Cache-Control": "no-cache"})
