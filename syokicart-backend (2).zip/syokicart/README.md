# SyokiCart backend (FastAPI + SQLite)

Serves the frontend at `/` and the API at `/api/*`. Payment collection is NOT implemented: orders stay `payment_status: "pending"`.

## Run
    pip install -r requirements.txt
    uvicorn server:app --host 0.0.0.0 --port 8000
Open http://localhost:8000. Log in with any Kenyan number; in dev mode the code is always `123456`.

## Test accounts
- `0700000000` admin (can set roles from the admin screen)
- `0711000001` vendor for Naivas (accept / ready orders)
- Any number can be made a `rider` by the admin; riders use `GET /api/rider/jobs` and `POST /api/rider/jobs/{id}/status` (out_for_delivery, delivered) to finish rider-delivered orders.

## Going live
Set env vars: `SYOKI_DEV_OTP=0` (random codes, no code in the API response), `SYOKI_DB=/data/syokicart.db` (put it on a persistent disk),
`AT_USERNAME`, `AT_API_KEY`, `AT_SENDER` for Africa's Talking SMS (without them codes are printed to the server log),
`SYOKI_ADMIN_PHONES`, `SYOKI_VENDOR_SEED` (`phone:slug,...`), `SYOKI_CORS`. Serve behind HTTPS (Render, Railway, Fly, a VPS with Caddy/nginx). A Dockerfile and Procfile are included. Run a single worker (SQLite).
